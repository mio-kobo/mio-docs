---
title: Bunko 与 Kiso API
description: 从真实 koukai 声明建立的标准库参考。
---

Bunko 是物理目录 `bunko/`，Kiso 是公开导入路径 `kiso/`。例如 `yobu "kiso/math";`；不要写 `bunko/kiso/math`。每个目录是包，同目录普通 .mio 文件组合加载，子目录不隐式包含。

## 基础 API

- [kiso/array](/docs/kiso/array)
- [kiso/bytes](/docs/kiso/bytes)
- [kiso/string](/docs/kiso/string)
- [kiso/utf8](/docs/kiso/utf8)
- [kiso/path](/docs/kiso/path)
- [kiso/convert](/docs/kiso/convert)
- [kiso/math](/docs/kiso/math)
- [kiso/io](/docs/kiso/io)
- [kiso/fs](/docs/kiso/fs)
- [kiso/encoding/binary](/docs/kiso/encoding-binary)
- [kiso/encoding/mochi](/docs/kiso/encoding-mochi)
- [kiso/testing](/docs/kiso/testing)

## 编译工具链 API

- [开发中编译模块](/docs/kiso/compiler-modules)

上列页面给出源码原样签名、公开数据类型、参数/返回语义、错误和独立示例。签名资料使用 text，只有完整可运行程序使用 mio 代码块。除 testing 专用包外，完整示例以 Go 引导 CLI 在 Mochi VM 实际执行。

## 支持边界

普通 CLI 注册 NativeFS MMA，testing 只在 mio test 注册。私有 `__...` 原语及 `mio/fs/runtime` 宿主 ABI 不是普通 Kiso 公共兼容承诺。公开字段当前无私有可见性，包含数组的 Builder/Buffer 值复制会共享存储。

VM 成功不代表纯 Mio Native 后端完整支持；M17e 尚未验收、M18 尚未启动。Compiler A 已生成并启动，A→B 仍被目标 Heap OOM 阻塞。

来源为 `bunko/kiso/**/*.mio`、`internal/typecheck/builtin.go`、`internal/value/`、`internal/nativefs/fs.go`、`internal/stdlib/registry.go` 与 CLI 库测试。完整源锁、API 声明比对与验证范围见 [验证与来源](/docs/tooling/verification)。
