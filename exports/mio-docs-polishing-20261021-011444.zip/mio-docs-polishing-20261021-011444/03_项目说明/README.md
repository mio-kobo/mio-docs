# Mio Docs · 澪光

独立 mio-docs 仓库中的正式文档网站。Next.js App Router + Fumadocs MDX Macro API + Fumadocs UI；使用官方 `root: "version"` 版本目录与原生侧栏选择器。

## 本地运行

使用 Node.js 22 或更新的兼容 LTS 与现有 npm 锁文件：

```sh
npm ci
npm run dev
npm run types:check
npm run test:versions
npm run check:versions
npm run check:links
npm run build
npm run start -- --hostname 127.0.0.1 --port 3210
BASE_URL=http://127.0.0.1:3210 npm run test:versions
BASE_URL=http://127.0.0.1:3210 npm run check:links
# 可选外链联网检查
CHECK_EXTERNAL=1 npm run check:links
```

`/docs` 进入最新正式 Stable，当前 `/docs/v1.0`；`/docs/v2.0` 是显式 Development。注册表 `content/versions.json` 支持 `2.1`、`2.10`、`3.1.2` 等数字版本，不为示例版本生成公开空页。旧 URL 和 B 的未版本化资料保留；它们不自动归属稳定版本，也不混入版本搜索。

侧栏顶部原生版本下拉框在桌面/手机上均可用；切换优先投影同名章节，缺页回目标版本首页并提示。可从 `/docs/v2.0/development` 切到 V1.0 验证真实回退。搜索默认当前版本，服务端也强制单一版本过滤，并标明每条结果的版本。

当前只提供中文。英文/日文路由已预留，未翻译路径返回 404，source 禁止中文 fallback 假装译文。

## 示例验证

分别使用各版本固定提交构建的 CLI；源码默认 CLI 字符串与 Release 标签可能不同，详细来源见 `content/LEARN_SOURCES.json`：

```sh
DOCS_VERSION=v1.0 MIO_CLI=/path/to/v1/mio MIO_BUNKO=/path/to/v1/bunko npm run check:examples
DOCS_VERSION=v2.0 MIO_CLI=/path/to/v2/mio MIO_BUNKO=/path/to/v2/bunko npm run check:examples
```

教程验证器检查当前各版的普通程序、原五课练习及 Hello 的 Mochi build/exec/disasm。完整内容验证（含测试包、新增练习、技术参考和 API 声明）使用下面的独立流程。脚本只在系统临时目录构建与运行，不修改核心仓库。

## 新增文档版本

```sh
npm run docs:version -- --version <主.次[.修订]> --commit <真实40位提交> --ref <真实来源ref>
```

只生成 `.docs-drafts/` 中未公开的目录、版本元数据与迁移指南模板。填写真实内容、审阅证据后才可执行 `--activate <版本id>`；Stable 激活还会核对正式 Release 与提交。已注册版本拒绝覆盖，历史正文有 SHA-256 锁，不能在新增版本时自动刷新。该工具不创建 Git tag、GitHub Release、Commit 或 Push。

详细 URL、术语、国际化、发布流程与 A/B 文件所有权见 [DOCS_CONTRACT.md](./DOCS_CONTRACT.md)。A 不改 B 技术正文、既有用户改动或相邻仓库；已有 pnpm 文件保留。

## 设计与边界

Mio Hikari / 澪光：Light `#4370B9`、Dark `#91BEF6`，点缀 `#A99BDD` / `#79C5C7`，暗色背景 `#0E1728`。

M17e 尚未验收，M18 尚未启动。纯 Mio 原生自举、WebAssembly Playground 不能作为已发布功能宣传。本站本地构建不等于站点部署。

[Fumadocs 官方版本机制](https://www.fumadocs.dev/docs/navigation) · [官方 Next.js 集成](https://www.fumadocs.dev/docs/mdx/next)。2026-10-20 npm 稳定版：Core/UI `16.17.7`、MDX `15.4.8`，沿用现有依赖。

## 内容质量审查与冻结勘误

```sh
python3 scripts/check-content-quality.py --core /absolute/path/to/mio --go-tests
```

验证器分别从 `content/versions.json` 的精确提交取 `git archive`，构建各版 CLI；逐字节检查完整 Mio 示例、测试包、练习及反例，并核对 171/358 条对应版本的公开声明。完整命令、环境、退出码、stdout/stderr 和源码哈希见 `verification/content-quality/results.json`。首次失败记录保留，不以重跑覆盖历史结论。

审计与处置见 `verification/content-quality/AUDIT.md`、`page-review.json` 和 `RESULT.md`；修订页面来源见 `content/QUALITY_SOURCES.json`。V2 Development 正文已独立精修。V1 Stable 正文与历史锁保持原样，修订候选仅存 `.docs-drafts/corrections/v1.0`；审批材料与差异见 `.docs-drafts/corrections/PROPOSAL.md`。草稿验证不代表审核批准，不自动激活或刷新历史锁。

## V2.0.0 发布准备与预览

新增 `/releases/2.0.0`、`/releases/2.0.0/migration`、`/download`、`/download/2.0.0`。默认 `/docs` 仍为 V1.0 Stable，V2.0.0 页面标注发布准备并 noindex；V2 没有伪造安装包。`content/downloads.json` 记录五个已实际下载核验的 V1.0.0 CLI/Bunko 包，平台运行测试并未全部覆盖。

可用 `MIO_DOCS_DIST_DIR=.next-release` 进行隔离构建，避免覆盖正在使用的 `.next`。预览：

```sh
MIO_DOCS_DIST_DIR=.next-release npm run build
MIO_DOCS_DIST_DIR=.next-release npm run start -- --hostname 127.0.0.1 --port 3211
BASE_URL=http://127.0.0.1:3211 npm run test:versions
BASE_URL=http://127.0.0.1:3211 npm run test:release
BASE_URL=http://127.0.0.1:3211 npm run check:links
npm run check:release -- --online
```

SEO 使用 `MIO_DOCS_SITE_URL` 的真实 HTTPS 站点源；未配置时 canonical 只以本地预览源生成，sitemap 为空，不能直接作为生产配置。sitemap 只收录 Stable/Legacy 文档及已开放的正式页面，Development 与 RC 继续 noindex。

### V2.0.0 正式切换（本轮不执行）

1. 先取得实际非 draft、非 prerelease 的 V2.0.0 官方 Release、精确提交与最终安装包。本网站流程不创建 Tag 或 Release。
2. `npm run docs:version -- --version 2.0.0 --commit <最终40位提交> --ref v2.0.0`。在 `.docs-drafts/v2.0.0` 审阅独立正文；B 负责技术部分，不能用开发快照冒充最终版本。填写实际 migration 与审阅证据，再设置 version.json 为 Stable、release 信息及 frozen=true。旧 v2.0 保持 Development。
3. 在隔离审阅副本中接入最终候选文档并运行完整网站验收（正式开关仍关闭，主工作区默认版不变）；将真实结果记录到正文 review.evidence 对应的 JSON：status=passed、精确 sourceCommit、reviewedBy 和 checks（项目同第 5 步）。Stable 激活现在也会检查这些验收项目；仅正文审阅通过不足以切换默认版。最终 Release Notes 和 Migration 页面按最终提交复核；填写 `content/downloads.json` 的 V2.0.0 记录。每个包实际下载，核对平台、架构、内部结构、大小、SHA256 与平台安装命令；不能仅按文件名猜测兼容性。
4. 先在本地执行 `npm run docs:version -- --activate v2.0.0`（自动验证官方 Release/提交和正文审阅）；它新增原生版本根并更新 defaultVersion，**此时 prepared 门禁应阻止生产构建**。没有完成后续验收前不要部署。
5. 在 `content/release-plan.json` 设置 `mode=live`、`docsVersion=v2.0.0`，保留 previousStable=v1.0；acceptance 填写 `status: passed`、sourceCommit、reviewer、reviewedAt（ISO 时间）、evidence（仓库相对 JSON 路径）。证据 JSON 必须有相同 sourceCommit、status=passed、reviewedBy 与 checks；checks 中 build/types/routes/versions/search/desktop/mobile/accessibility/artifacts/releaseNotes/migration 每项均为 passed。沿用第 3 步实际验收的证据，再由审阅者确认，禁止自动填 passed。
6. 设置真实 `MIO_DOCS_SITE_URL=https://<实际文档域名>`；运行 types:check、test:versions、test:release、check:versions、check:release -- --online、check:links 和 build。启动生产预览，带 BASE_URL 再跑路由/搜索/版本测试，复核桌面、手机、主题及键盘操作。门禁通过后，首页、默认文档与稳定下载才共同指向 V2.0.0。
7. 保留验收记录交维护者完成部署。本轮不部署。回滚需一起恢复 release-plan、versions 默认值与 downloads 到此前配置；不要删除已存在的旧 URL 或修改历史正文锁。

新增补丁与次版本同样使用 `2.0.1`、`2.1.0` 等完整版本号；测试 fixture 不产生公共空页面。发布状态支持 Development、Release Candidate、Stable、Legacy，兼容原 EOL；RC 必须有实际 prerelease，不接管稳定入口。
